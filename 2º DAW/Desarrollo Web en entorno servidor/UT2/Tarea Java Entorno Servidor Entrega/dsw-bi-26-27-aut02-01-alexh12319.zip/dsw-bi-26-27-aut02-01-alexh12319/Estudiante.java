public class Estudiante {
    private String nombre;
    private int edad;
    private double notaMedia;
    private boolean estadoMatricula;

    public Estudiante(String nombre, int edad, double notaMedia, boolean estadoMatricula) {
        this.nombre = nombre;
        this.edad = edad;
        this.notaMedia = notaMedia;
        this.estadoMatricula = estadoMatricula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getNotaMedia() {
        return notaMedia;
    }

    public void setNotaMedia(double notaMedia) {
        this.notaMedia = notaMedia;
    }

    public boolean getEstadoMatricula() {
        return estadoMatricula;
    }

    public void setEstadoMatricula(boolean estadoMatrícula) {
        this.estadoMatricula = estadoMatrícula;
    }


    public String toString(){
        String matriculita;
        if(estadoMatricula){
            matriculita = "Aprobada";
        }else{
            matriculita = "Suspendida";
        }
        return "Nombre: " + nombre + " Edad: " + edad + " nota media: " + notaMedia + " Matricula: " +  matriculita;
    }
}

