# AUT02_01 - Gestor de estudiantes

## Descripción

Una academia necesita una aplicación de consola que permita gestionar la información de sus estudiantes.

El objetivo de esta actividad es desarrollar la aplicación utilizando **Java** y aplicar los contenidos trabajados durante la **UT2 - Introducción a Java**.

La aplicación deberá permitir registrar estudiantes, consultar sus datos y obtener información sobre sus calificaciones.

---

## Datos de los estudiantes

Cada estudiante deberá disponer, como mínimo, de los siguientes datos:

- Nombre.
- Edad.
- Nota media.
- Estado de matrícula.

Deberás utilizar una clase `Estudiante` para representar esta información.

---

## Funcionalidades

Al ejecutar la aplicación se mostrará un menú que permita realizar las siguientes operaciones:

1. Añadir un estudiante.
2. Listar todos los estudiantes.
3. Buscar estudiantes por nombre.
4. Calcular la nota media general.
5. Mostrar el estudiante con mejor calificación.
6. Salir del programa.

El menú deberá repetirse hasta que el usuario seleccione la opción de salir.

### 1. Añadir estudiante

Se solicitarán los siguientes datos:

- Nombre.
- Edad.
- Nota media.
- Estado de matrícula.

El nuevo estudiante deberá almacenarse para poder utilizar posteriormente su información.

### 2. Listar estudiantes

Se mostrarán de forma clara y organizada los datos de todos los estudiantes registrados.

Si todavía no hay estudiantes registrados, el programa deberá indicarlo.

### 3. Buscar estudiantes por nombre

El usuario introducirá un nombre o parte de un nombre.

La búsqueda deberá:

- No distinguir entre mayúsculas y minúsculas.
- Permitir coincidencias parciales.
- Mostrar todas las coincidencias encontradas.

Por ejemplo, una búsqueda de:

```text
ale
```

podría encontrar:

```text
Alejandro
Alejandra
```

Si no existe ninguna coincidencia, el programa deberá indicarlo.

### 4. Calcular la nota media general

Se calculará y mostrará la media de las notas de todos los estudiantes registrados.

El programa deberá contemplar el caso de que todavía no haya estudiantes.

### 5. Mostrar el estudiante con mejor calificación

Se mostrará la información del estudiante que tenga la nota más alta.

El programa deberá contemplar el caso de que todavía no haya estudiantes.

### 6. Salir

La aplicación finalizará correctamente cuando el usuario seleccione esta opción.

---

## Validación de datos

La aplicación deberá evitar almacenar información incorrecta.

Como mínimo deberán cumplirse las siguientes condiciones:

- El nombre no podrá estar vacío.
- El nombre solo podrá contener letras y espacios.
- La edad no podrá ser negativa.
- La nota deberá estar comprendida entre `0` y `10`.
- El estado de matrícula deberá contener un valor válido.
- Las opciones incorrectas del menú deberán ser controladas.
- Una entrada de un tipo diferente al esperado no deberá provocar que el programa finalice inesperadamente.

### Nombres duplicados

Puedes decidir entre:

- No permitir estudiantes con el mismo nombre.
- Permitir estudiantes con el mismo nombre.

La decisión adoptada deberá aplicarse de forma coherente durante toda la aplicación.

Si permites nombres repetidos, una búsqueda deberá mostrar todas las coincidencias.

---

## Organización del código

El código deberá estar correctamente modularizado y aplicar los conceptos de orientación a objetos trabajados en clase.

Como mínimo deberán existir las siguientes clases:

```text
Main
 └── interacción con el usuario

Estudiante
 └── información del estudiante
```

Puedes crear otras clases si consideras que mejoran la organización del programa.

### Clase Estudiante

La clase `Estudiante` será la encargada de representar a cada estudiante.

Sus atributos deberán estar encapsulados utilizando `private`.

El acceso o modificación de estos atributos deberá realizarse mediante los métodos correspondientes.

Las validaciones relacionadas directamente con los atributos de un estudiante deberán realizarse, cuando corresponda, desde sus setters.

### Colección de estudiantes

La aplicación deberá utilizar una colección que permita almacenar varios objetos de tipo `Estudiante`.

Esta colección podrá encontrarse:

- En `Main`.
- En otra clase específicamente encargada de gestionar los estudiantes.

La colección nunca deberá encontrarse dentro de la propia clase `Estudiante`.

---

## Interacción con el usuario

Toda la interacción con el usuario deberá realizarse desde la clase `Main`.

Esto incluye:

- Solicitar información al usuario.
- Mostrar el menú.
- Mostrar los datos de los estudiantes.
- Mostrar resultados.
- Mostrar mensajes de error.

Por tanto, `Scanner`, `System.out.print`, `System.out.println` u otros mecanismos de interacción con el usuario no deberán utilizarse desde la clase `Estudiante` ni desde otras clases del programa.

Puedes crear métodos dentro de `Main` e invocarlos desde el método `main` para organizar correctamente esta interacción.

---

## Ejemplo de ejecución

La siguiente imagen muestra un posible resultado de la ejecución de la aplicación:

![Ejemplo de ejecución](Ejemplo.png)

No es necesario reproducir exactamente el aspecto visual mostrado en la imagen.

El diseño del menú y de la información mostrada puede ser diferente siempre que:

- Las funcionalidades solicitadas estén disponibles.
- La información sea clara.
- La aplicación sea sencilla de utilizar.

---

## Trabajo con Git

El desarrollo deberá realizarse utilizando este repositorio.

Deberás realizar como mínimo un **commit significativo** por cada uno de los siguientes hitos:

1. Creación del proyecto vacío.
2. Creación de la clase principal que contiene el método `main`.
3. Implementación de la opción para añadir un estudiante.
4. Implementación del listado de estudiantes.
5. Implementación de la búsqueda por nombre.
6. Implementación del cálculo de la media.
7. Implementación de la búsqueda del estudiante con mejor calificación.
8. Implementación de la opción para salir.

Los mensajes de los commits deberán describir claramente los cambios realizados.

Por ejemplo:

```text
Crea estructura inicial del proyecto
Implementa alta de estudiantes
Implementa listado de estudiantes
Implementa búsqueda por nombre
Implementa cálculo de la nota media
```

Puedes realizar todos los commits adicionales que necesites durante el desarrollo.

No es necesario limitarse a los commits indicados anteriormente.

---

## Registro del tiempo

Deberás registrar el tiempo dedicado a la realización de la actividad utilizando **Clockify o una aplicación similar de control de tiempo**.

El registro deberá realizarse durante el desarrollo de la actividad, tanto dentro como fuera del aula.

Al finalizar deberás:

1. Realizar una captura en la que pueda comprobarse el tiempo registrado.
2. Adjuntar la captura en la entrega correspondiente de EVAGD.
3. Indicar el tiempo total dedicado en el texto de la entrega.

El objetivo de este registro no es valorar quién tarda más o menos en realizar la actividad, sino disponer de información sobre el tiempo necesario para completarla.

---

## Autoevaluación

Antes de realizar la entrega definitiva deberás revisar tu propio proyecto utilizando la rúbrica de autoevaluación proporcionada en EVAGD.

No deberás comprobar únicamente si el programa funciona.

También deberás revisar:

- Las funcionalidades solicitadas.
- Las validaciones.
- La organización y modularización del código.
- El uso de clases y objetos.
- La encapsulación.
- La interacción con el usuario.
- El historial de commits.

La valoración deberá realizarse basándose en evidencias que puedas comprobar en tu propio proyecto.

El archivo deberá entregarse en EVAGD con el nombre:

```text
autoevaluacion.ods
```

---

## Entrega

El código definitivo deberá quedar correctamente subido a este repositorio.

Además, en la actividad correspondiente de EVAGD deberás entregar:

- El proyecto completo comprimido en formato `.zip`.
- Una captura del tiempo registrado con Clockify o una aplicación similar.
- El tiempo total dedicado, indicado en el texto de la entrega.
- La rúbrica de autoevaluación con el nombre `autoevaluacion.ods`.

La entrega del archivo `.zip` no sustituye al repositorio.

Durante el desarrollo deberás trabajar normalmente con Git y mantener actualizado el repositorio.

Tanto el estado final del proyecto como el historial de commits podrán ser revisados durante la evaluación.

---

## Coevaluación

Una vez finalizado el plazo de entrega se realizará una segunda fase de coevaluación.

Se te asignará el proyecto de otra persona de la clase.

Cuando comience esta fase deberás:

1. Acceder al repositorio de la persona asignada.
2. Clonar el repositorio en tu equipo.
3. Ejecutar y probar la aplicación.
4. Revisar el código fuente.
5. Revisar el historial de commits.
6. Completar la rúbrica de coevaluación.

La evaluación deberá realizarse basándose únicamente en evidencias que puedas comprobar.

La coevaluación tendrá una actividad de entrega independiente en EVAGD.

Por tanto, **no deberás entregar la coevaluación junto con la entrega principal de AUT02_01**.

Cuando comience esta fase se indicará qué persona debes evaluar y se proporcionará la correspondiente plantilla de coevaluación.

El archivo deberá guardarse utilizando como nombre el de la persona evaluada.

Por ejemplo:

```text
Gonzalo.ods
```

---

## Ampliaciones voluntarias

Una vez implementados correctamente todos los requisitos obligatorios, puedes incorporar mejoras adicionales.

Por ejemplo:

- Ordenar los estudiantes por nombre.
- Ordenar los estudiantes por nota.
- Incorporar nuevas estadísticas.
- Añadir filtros para consultar estudiantes.
- Mejorar la presentación del menú.
- Incorporar otras funcionalidades que consideres útiles.

Las ampliaciones no sustituyen ninguno de los requisitos obligatorios.

Antes de comenzar una ampliación, asegúrate de que las funcionalidades obligatorias funcionan correctamente.
