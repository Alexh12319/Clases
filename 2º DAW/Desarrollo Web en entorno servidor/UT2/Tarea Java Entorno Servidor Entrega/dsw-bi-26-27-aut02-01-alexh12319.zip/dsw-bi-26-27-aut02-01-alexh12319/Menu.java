import java.util.Scanner;
import java.util.ArrayList;
import java.util.InputMismatchException;

//No compila pues aun no he programado gestor
public class Menu {
    public static void main(String[] args) {
        GestorEstudiantes gestor = new GestorEstudiantes();
        Scanner sc = new Scanner(System.in);
        boolean opcionValida = false;

        do {


                int opcion = -1;

                do {

                    try {
                    System.out.println("+---------MENÚ----------+");
                    System.out.println("|1. Añadir estudiante   |");
                    System.out.println("|2. Listar estudiantes  |");
                    System.out.println("|3. Buscar estudiante   |");
                    System.out.println("|4. Calcular media total|");
                    System.out.println("|5. Mejor estudiante    |");
                    System.out.println("|6. Guardar Estudiantes |");
                    System.out.println("|7. Cargar Estudiantes  |");
                    System.out.println("|8. Salir               |");
                    System.out.println("|Elige una opción:      |");
                    System.out.println("+-----------------------+");
                    opcion = sc.nextInt();
                    sc.nextLine();

                    switch (opcion) {

                        case 1:
                            //Validacion de nombre:
                            String nombre = validarNombre();

                            //validacion de campo en edad
                            int edad = validarEdad();

                            //Validacion de nota
                            double notaMedia = ValidarNotaMedia();

                            //Validacion de rango
                            boolean matricula = ValidarMatricula();

                            //+---------------------------------------------------+
                            //|Si o si debe estar esto aqui pues                  |
                            //|Aqui valido tanto si todos los datos se introducen |
                            //|Como si ya se añadió de antemano                   |
                            //+---------------------------------------------------+
                            boolean seAñadio = false;
                            do{
                                if (matricula) {
                                    try{
                                        gestor.AñadirEstudiante(nombre, edad, notaMedia, matricula);
                                        seAñadio = true;
                                    }catch(EstudianteDuplicadoException e){
                                        System.out.println(e.getMessage());
                                    }
                                }
                                break;
                            }while(seAñadio = false);
                            break;
                        case 2:
                            if (gestor.LlamarArrayList().size() == 0) {
                                System.out.println("Mete algún estudiante para poder trabajar");
                            } else {
                                for (int i = 0; i < gestor.LlamarArrayList().size(); i++) {
                                    System.out.println(" ");
                                    System.out.println(gestor.LlamarArrayList().get(i));
                                }
                            }
                            break;

                        case 3:
                            if (gestor.LlamarArrayList().size() == 0) {
                                System.out.println("Mete algún estudiante para poder trabajar");
                            } else {
                                String nombreBuscado = validarNombre();

                                ArrayList<Estudiante> resultado = gestor.BuscarPorNombre(nombreBuscado);

                                for (int i = 0; i < resultado.size(); i++) {
                                    System.out.println(" ");
                                    System.out.println(resultado.get(i));
                                }
                            }

                            break;
                        case 4:
                            if (gestor.LlamarArrayList().size() == 0) {
                                System.out.println("Mete algún estudiante para poder trabajar");
                            } else {
                                System.out.println("La nota media total de los alumnos es de: " + gestor.MediaTotal());
                            }
                            break;

                        case 5:
                            if (gestor.LlamarArrayList().size() == 0) {
                                System.out.println("Mete algún estudiante para poder trabajar");
                            } else {
                                ArrayList<Estudiante> mejoresEstudiantes = gestor.MejorEstudiante();

                                for (int j = 0; j < mejoresEstudiantes.size(); j++) {
                                    System.out.println(" ");
                                    System.out.println(mejoresEstudiantes.get(j));
                                }
                            }

                            break;


                        case 6:
                            if (gestor.LlamarArrayList().size() == 0) {
                                System.out.println("Mete algún estudiante para poder trabajar");
                            } else {
                                if (gestor.GuardarEstudiantes() == false) {
                                    System.out.println("Hubo un problema al guardar los estudiantes");
                                } else {
                                    System.out.println("Se escribió correctamente");
                                }
                            }
                            break;

                        case 7:
                            if (gestor.CargarDeFichero() == false) {
                                System.out.println("Hubo un problema al cargar los estudiantes");
                            } else {
                                System.out.println("Se cargó correctamente");
                            }
                            break;

                        case 8:
                            System.out.println("Saliendo... ");
                            break;

                        default:
                            System.out.println("Opción no válida");
                            break;

                    }
                    opcionValida = true;
                } catch (Exception InputMismatchException) {
                    System.out.println("Solo opción numérica");
                    sc.nextLine();
                }

                } while (opcion != 8);


        } while (opcionValida == false);
    }

    //Métodos de validación:

    public static String validarNombre(){
        Scanner sc = new Scanner(System.in);
        String nombre = "";

        boolean noMatch;
        do {
            System.out.println("Indique el nombre: ");
            nombre = sc.nextLine();

            noMatch = (!nombre.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+") || nombre.trim().isEmpty());

            if (noMatch) {
                System.out.println("Introduzca un campo válido.");
            }

        } while (noMatch);

        return nombre;
    }

    public static int validarEdad(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Indique la edad: ");

        //Aqui valido que el usuario introdució un número
        int campo = 0;
        boolean EntradaCorrectaEdad = false;
        do {
            try {
                do {
                    campo = sc.nextInt();
                    if (campo < 0) {
                        System.out.println("La edad no puede ser negativa");
                    }
                } while (campo < 0);
                EntradaCorrectaEdad = true;
            } catch (Exception InputMismatchException) {
                System.out.println("no son letras, son numeros");
                sc.nextLine();
            }
        } while (!EntradaCorrectaEdad);

        return campo;
    }

    public static double ValidarNotaMedia(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Indique su nota media: ");
        boolean EntradaCorrecta = false;
        boolean RangoCorrecto = false;
        double notaMedia = -1;
        do {
            try {
                do {
                    double campito = sc.nextDouble();
                    if (campito >= 0.0 && campito <= 10.0) {
                        notaMedia = campito;
                        RangoCorrecto = true;
                    } else {
                        System.out.println("El rango debe estar entre 0 y 10");
                    }
                } while (!RangoCorrecto);
                EntradaCorrecta = true;
            } catch (Exception InputMismatchException) {
                System.out.println("no son letras, son numeros");
                sc.nextLine();
            }
        } while (!EntradaCorrecta);

        sc.nextLine();

        return notaMedia;

    }

    public static boolean ValidarMatricula(){
        Scanner sc = new Scanner(System.in);
        boolean matricula = false;
        boolean entradaValida = false;

        //Aquí valido la entrada del usuario
        do {
            System.out.println("la matricula fue aceptada? ");
            System.out.print("y/n: ");

            String confirmacion = sc.nextLine();

            if (confirmacion.equals("y")) {
                matricula = true;
                entradaValida = true;
            } else if (confirmacion.equals("n")) {
                matricula = false;
                entradaValida = true;
                System.out.println("El alumno no entró");
            } else {
                System.out.println("solo y/n");
            }
        } while (!entradaValida);

        return matricula;
    }
}