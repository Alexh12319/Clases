import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class GestorEstudiantes {
    ArrayList<Estudiante> estudiantes;

    public GestorEstudiantes() {
        estudiantes = new ArrayList<>();
    }

    public void AñadirEstudiante(String nombre, int edad,double notaMedia, boolean matricula) throws EstudianteDuplicadoException {

        for (int i = 0; i < estudiantes.size(); i++) {
                if (estudiantes.get(i).getNombre().equals(nombre)) {
                    throw new EstudianteDuplicadoException("Ese alumno ya existe");
                }
            }

        Estudiante alumnito = new Estudiante(nombre, edad, notaMedia, matricula);
            estudiantes.add(alumnito);
    }

    public ArrayList LlamarArrayList(){
        return estudiantes;
    }

    public ArrayList<Estudiante> BuscarPorNombre(String nombre) {
        ArrayList<Estudiante> ListaResultante = new ArrayList<>();

        for(int i = 0; i < estudiantes.size(); i++){
            if(estudiantes.get(i).getNombre().toLowerCase().contains(nombre.toLowerCase())){
                ListaResultante.add(estudiantes.get(i));
            }
        }
        return ListaResultante;
    }

    public double MediaTotal(){
        double resultado = 0.0;
        int contador = 0;
        for(int i = 0; i < estudiantes.size(); i++){
            resultado += estudiantes.get(i).getNotaMedia();
            contador ++;
        }
        double media = resultado/contador;
        double mediaRedondeada = Math.round(media * 100.0) /100.0; //Los limita a dos decimales
        return mediaRedondeada;
    }

    public ArrayList<Estudiante> MejorEstudiante(){
        ArrayList<Estudiante> empoyones = new ArrayList<>();
        Estudiante mejorAlumnito = new Estudiante("", 0, 0, false);
        double mejorNota = -1.0;
        for (int i = 0; i < estudiantes.size(); i++){
            if(estudiantes.get(i).getNotaMedia() > mejorNota){
                empoyones.clear(); //Por si acaso, pero creo que lo hace automatico
                mejorAlumnito = estudiantes.get(i);
                empoyones.add(mejorAlumnito);
                mejorNota = estudiantes.get(i).getNotaMedia();
            }else if(estudiantes.get(i).getNotaMedia() == mejorNota){
                empoyones.add(estudiantes.get(i));
            }
        }
        return empoyones;
    }


    public boolean GuardarEstudiantes(){
        boolean funciono = false;
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("Estudiantes.txt"));
            for (int i = 0; i < estudiantes.size(); i++){
                bw.write("" + estudiantes.get(i).getNombre());
                bw.newLine();
                bw.write("" + estudiantes.get(i).getEdad());
                bw.newLine();
                bw.write("" + estudiantes.get(i).getNotaMedia());
                bw.newLine();
                bw.write("" + estudiantes.get(i).getEstadoMatricula());
                bw.newLine();
            }
            bw.close();

            funciono = true;
        } catch (IOException e) {
           funciono = false;
        }
        return funciono;
    }


    public boolean CargarDeFichero(){
        try {
            BufferedReader br = new BufferedReader(new FileReader("Estudiantes.txt"));

            String nombre = "";
            int edad = 0;
            double notaMedia = 0;
            boolean matricula = false;

            while ((nombre = br.readLine()) != null) { // Si hay datos
                edad = Integer.parseInt(br.readLine()); //Lo pasa a int
                notaMedia = Double.parseDouble(br.readLine()); //Lo pasa a double
                matricula = Boolean.parseBoolean(br.readLine()); //Lo pasa a boolean
                Estudiante alumno = new Estudiante(nombre, edad, notaMedia, matricula);
                estudiantes.add(alumno);
            }

            br.close();
            return true;

        } catch (IOException e) {
            return false;
        }
    }
}

